package com.example.demo.service;

import com.example.demo.models.Post;

public interface IPostService extends IGenericService<Post>{
}
