create database testapp;
use testapp;
create table utilisateur (
id int auto_increment primary key ,
username varchar(25),
motdepass varchar (50)
);
